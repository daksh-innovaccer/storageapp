import Card from "../UI/Card/Card"
import Button from "../UI/Button/Button";
import "./Login.css"
const Login = () => {
    return (
        <Card className="login">
            <form>
                <div className="control">
                    <label htmlFor="email">E-mail </label>
                    <input type="email" name="email" id="email"/>
                </div>
                <div className="control">
                    <label htmlFor="password">Password </label>
                    <input type="password" name="password" id="password" />
                </div>
                <div className="actions">
                    <Button type="submit">Login</Button>
                </div>
            </form>
        </Card>
    )
}

export default Login